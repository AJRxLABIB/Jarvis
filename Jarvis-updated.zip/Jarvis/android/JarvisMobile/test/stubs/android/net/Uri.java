package android.net;
public abstract class Uri { public static Uri parse(String s) { return null; } }
