"""Autonomy levels - how much Jarvis may do on its own. Enforced by the action executor for EVERY caller (GUI, voice,
phone, schedules, agents), never by the model's own reasoning; the model cannot change the level.

* observe  - only reads: answers, searches, looks at the screen/files/devices; nothing is changed, opened or sent.
* routine  - the normal behaviour: low-risk actions run, riskier ones ask (default).
* approval - every action that changes something asks first; no standing approvals and no "direct command" shortcut.

Emergency stop and switching Jarvis's own windows always work.
"""

from __future__ import annotations

LEVELS = ("observe", "routine", "approval")

# tools that only read / report. Anything not listed is treated as changing something.
READ_ONLY = frozenset({
    "activity_timeline", "ask_documents", "ask_history", "ask_knowledge", "browser_read", "calculate",
    "calendar_events", "check_device", "check_project", "code_impact", "command_center", "current_context",
    "daily_briefing", "describe_screen", "dev_environment", "device_info", "diagnose_jarvis", "explain_action",
    "explain_memory", "file_info", "find_files", "find_my_files", "find_duplicates", "get_datetime", "get_news",
    "get_weather", "git_log", "git_status", "health_history", "home_status", "integrations", "list_agents",
    "list_automations", "list_contacts", "list_devices", "list_folder", "list_goals", "list_nicknames",
    "list_processes", "list_proposals", "list_todos", "list_undoable", "mission_history", "mission_status",
    "model_status", "pc_health", "program_history", "project_profile", "read_clipboard", "read_code", "read_emails",
    "read_messages", "read_screen", "read_whatsapp", "recall", "recall_activity", "review_changes",
    "review_mistakes", "search_code", "search_everything", "search_history", "security_scan", "show_proposal",
    "simulate_workflow", "system_status", "trace_request", "voice_stats", "what_can_you_do", "what_do_you_know",
    "workflow_versions", "web_search", "plan_my_day", "calendar_conflicts",
})
ALWAYS = frozenset({"emergency_control", "jarvis_control"})       # stopping, and Jarvis's own screens


def normalise(value: str | None) -> str:
    value = (value or "routine").strip().lower()
    return value if value in LEVELS else "routine"


def is_read_only(tool: str, arguments: dict | None = None) -> bool:
    if tool == "batch_rename":
        return not (arguments or {}).get("apply")                    # a preview only reads
    if tool == "phone_control":
        return (arguments or {}).get("action") == "status"
    if tool in ("journal", "habits"):
        return (arguments or {}).get("action") in ("list", "search", "today", "report", "streaks")
    if tool == "expenses":
        return (arguments or {}).get("action") in ("list", "report", "budgets", "trend")
    return tool in READ_ONLY


def blocked_in(level: str, tool: str, arguments: dict | None = None) -> str | None:
    """Why ``tool`` may not run at this autonomy level at all (None = it may)."""
    if normalise(level) == "observe" and tool not in ALWAYS and not is_read_only(tool, arguments):
        return ("Observe mode: I only look and read, I don't change anything. Switch to 'routine' in "
                "Settings > Security to let me act.")
    return None


def must_ask(level: str, tool: str, arguments: dict | None = None) -> bool:
    """Approval mode: everything that changes something asks first."""
    return normalise(level) == "approval" and tool not in ALWAYS and not is_read_only(tool, arguments)
