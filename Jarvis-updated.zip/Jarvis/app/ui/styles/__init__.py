"""Visual theme."""
